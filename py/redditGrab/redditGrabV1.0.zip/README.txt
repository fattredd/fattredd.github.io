# README
# Version 1.0 
#
# Grab the top 10 images on reddit
# Use from the command line by calling
# python redditGrab.py [number] [subreddit]
#